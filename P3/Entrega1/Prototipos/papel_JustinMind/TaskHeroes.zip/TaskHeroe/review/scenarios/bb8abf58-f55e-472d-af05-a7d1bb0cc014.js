var content='<div id="sc-bb8abf58-f55e-472d-af05-a7d1bb0cc014" class="ui-page ui-scenario sc-bb8abf58-f55e-472d-af05-a7d1bb0cc014 " name="Board 1">\
	<link type="text/css" rel="stylesheet" href="./review/scenarios/bb8abf58-f55e-472d-af05-a7d1bb0cc014/style-1734629885187.css" />\
    <div class="filterDialog">\
      <span id="filterDialogImage"></span>\
      <span id="filterDialogTitle">Start User flow</span>\
      <span id="filterDialogText">You will only be able to navigate through the screens of this User flow. To exit the User flow, simply remove the filter from the toolbar.</span>\
      <div id="filterDialogButtons">\
        <div id="startScenarioButton" class="scenarioButton">Start</div>\
        <div id="openPageButton" class="scenarioButton">Cancel</div>\
      </div>\
      <div id="filterCloseButton"></div>\
    </div>\
    <div class="scenarioShadow"></div>\
    <div id="scenarioWrapperMargin">\
	    <div id="scenarioWrapper">\
	    </div>\
    </div>\
   	<div id="scenarioBgBox" ></div>\
   	<div id="loadMark"></div>\
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;